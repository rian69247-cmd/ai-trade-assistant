export default function Plan() {
  return (
    <main className="min-h-screen bg-gray-900 text-white p-6">
      <h2 className="text-2xl font-bold mb-4">Generate AI Trade Plan (Demo)</h2>
      <p>Gunakan tombol "Generate" untuk memanggil API dummy.</p>
    </main>
  )
}
